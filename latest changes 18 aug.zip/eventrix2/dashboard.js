// ====== constants & auth ======
const bodyEl = document.body;
const themeToggle = document.getElementById("theme-toggle");
const avatarBtn = document.getElementById("avatarBtn");
const drawer = document.getElementById("drawer");
const drawerClose = document.getElementById("drawerClose");

const shell = document.querySelector(".shell");
const hamburger = document.getElementById("hamburger");
const collapsedPlus = document.getElementById("collapsedPlus");
const collapsedCreate = document.getElementById("collapsedCreate");

const tabWeek = document.getElementById("viewWeek");
const tabMonth = document.getElementById("viewMonth");
const todayBtn = document.getElementById("todayBtn");

const monthLabel = document.getElementById("monthLabel");
const monthLabelBtn = document.getElementById("monthLabelBtn");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");

const weekGrid = document.getElementById("weekGrid");
const timeCol = document.getElementById("timeCol");
const dowEls = document.querySelectorAll(".cal-header .dow");

const monthGrid = document.getElementById("monthGrid");
const monthHeader = document.getElementById("monthHeader");

const miniCalendar = document.getElementById("miniCalendar");
const miniTitle = document.getElementById("miniTitle");
const miniPrev = document.getElementById("miniPrev");
const miniNext = document.getElementById("miniNext");
const monthPopup = document.getElementById("monthPopup");
const popCalendar = document.getElementById("popCalendar");
const popTitle = document.getElementById("popTitle");
const popPrev = document.getElementById("popPrev");
const popNext = document.getElementById("popNext");

const upcomingList = document.getElementById("upcomingList");
const tasksList = document.getElementById("tasksList");
const addTaskBtn = document.getElementById("addTaskBtn");

const infoUsername = document.getElementById("infoUsername");
const infoRole = document.getElementById("infoRole");

const BackendUrl = "https://dexter.xtrayambak.xyz";

// Auth struct matches your existing index.js/login
class AuthInfo {
  constructor(username, password, token, tokenExpiry, role) {
    this.username = username;
    this.password = password;
    this.token = token;
    this.tokenExpiry = tokenExpiry;
    this.role = role; // 0 admin, 1 participant
  }
}
let authInfo = new AuthInfo(
  localStorage.getItem("username"),
  localStorage.getItem("password"),
  undefined,
  1,
  1
);

function avatarFrom(name) {
  return (name?.[0] || "U").toUpperCase();
}
function populateDrawer() {
  infoUsername.textContent = authInfo.username;
  infoRole.textContent = authInfo.role === 0 ? "Administrator" : "Participant";
  avatarBtn.textContent = avatarFrom(authInfo.username);
}

// login + token refresh
async function updateAuthInfo() {
  try {
    const resp = await fetch(`${BackendUrl}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: authInfo.username,
        password: authInfo.password,
      }),
    });
    if (!resp.ok) {
      window.location.href = "../index.html";
      return;
    }
    const body = await resp.json();
    authInfo = new AuthInfo(
      authInfo.username,
      authInfo.password,
      body.token.code || body.token,              // supports doc + current backend
      body.token.expires_at || body.token.expiresAt || Date.now() / 1000 + 3600,
      body.details.role
    );
    populateDrawer();
    const ms = (authInfo.tokenExpiry * 1000) - Date.now();
    setTimeout(updateAuthInfo, Math.max(10000, ms)); // re-login before expiry
  } catch (e) {
    console.error(e);
    window.location.href = "../index.html";
  }
}

// theme
function setLogos() {
  const src = bodyEl.classList.contains("light") ? "logo-light.png" : "logo-dark.png";
  document.getElementById("sideLogo").src = src;
}
themeToggle.addEventListener("click", () => {
  bodyEl.classList.toggle("light");
  themeToggle.textContent = bodyEl.classList.contains("light") ? "☀ Light" : "🌙 Dark";
  setLogos();
  localStorage.setItem("theme", bodyEl.classList.contains("light") ? "light" : "dark");
});
const savedTheme = localStorage.getItem("theme");
if (savedTheme === "light") {
  bodyEl.classList.add("light"); themeToggle.textContent = "☀ Light";
} else { bodyEl.classList.remove("light"); themeToggle.textContent = "🌙 Dark"; }
setLogos();

// drawer
avatarBtn.addEventListener("click", () => drawer.classList.add("open"));
drawerClose.addEventListener("click", () => drawer.classList.remove("open"));
document.addEventListener("click", (e) => {
  if (drawer.classList.contains("open") && !drawer.contains(e.target) && !avatarBtn.contains(e.target)) {
    drawer.classList.remove("open");
  }
});

// ====== calendar state/render ======
const monthNames = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const dowNames = ["SUN","MON","TUE","WED","THU","FRI","SAT"];
let current = new Date();
let currentView = "week";

function startOfWeek(d) {
  const date = new Date(d);
  const day = date.getDay();
  const diff = date.getDate() - day;
  return new Date(date.setDate(diff));
}
function updateMonthLabel() {
  monthLabel.textContent = `${monthNames[current.getMonth()]} ${current.getFullYear()}`;
}

// time column
(function paintTimeCol(){
  timeCol.innerHTML = "";
  for (let h=0; h<24; h++){
    const r = document.createElement("div");
    r.className = "time-row";
    r.textContent = `${String(h).padStart(2,"0")}:00`;
    timeCol.appendChild(r);
  }
})();

// build week columns
function buildColumns() {
  weekGrid.innerHTML = "";
  for (let i=0; i<7; i++) {
    const col = document.createElement("div");
    col.className = "day-col";
    col.dataset.dayIndex = i;
    weekGrid.appendChild(col);
  }
}
buildColumns();

function updateHeaderDates(baseDate) {
  const start = startOfWeek(baseDate);
  const today = new Date();
  dowEls.forEach((el, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const isToday = d.toDateString() === today.toDateString();
    el.classList.toggle("today", isToday);
    el.innerHTML = `<div class="name">${dowNames[i]}</div><div class="date">${d.getDate()}</div>`;
    el.dataset.iso = d.toISOString().slice(0,10);
  });
}

let events = []; // normalized for UI
// structure: { name,title,venue,participants[],startEpoch,endEpoch,day, startHHMM,endHHMM }

function toHHMM(ts){
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
}

async function getEvents() {
  try {
    const resp = await fetch(`${BackendUrl}/events/list`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${authInfo.token}`,
      },
    });
    if (!resp.ok) return;
    const body = await resp.json();
    const list = body.events || [];
    events = list.map(e => {
      const startTs = Number(e.date);
      const endTs = Number(e.end);
      const d = new Date(startTs);
      return {
        name: e.name,
        title: e.name,
        venue: e.venue,
        participants: Array.isArray(e.participants) ? e.participants : String(e.participants || "").split(";").filter(Boolean),
        startEpoch: startTs,
        endEpoch: endTs,
        day: d.getDay(),
        startHHMM: toHHMM(startTs),
        endHHMM: toHHMM(endTs),
      };
    });
    renderEvents();
    paintUpcoming();
  } catch (e) {
    console.error("getEvents error", e);
  }
}

function toMinutes(hhmm){ const [h,m] = hhmm.split(":").map(Number); return h*60+m; }
function renderEvents() {
  document.querySelectorAll(".day-col").forEach(col => col.innerHTML = "");
  events.forEach(ev => {
    const col = weekGrid.querySelector(`.day-col[data-day-index="${ev.day}"]`);
    if (!col) return;
    const top = toMinutes(ev.startHHMM);
    const height = Math.max(30, toMinutes(ev.endHHMM) - toMinutes(ev.startHHMM));
    const el = document.createElement("div");
    el.className = "event";
    el.style.top = `${top}px`;
    el.style.height = `${height}px`;
    el.innerHTML = `<div class="evt-title"><strong>${ev.title}</strong></div>
                    <div class="evt-meta">${ev.startHHMM} – ${ev.endHHMM}</div>
                    <div class="evt-venue">${ev.venue || ""}</div>`;
    el.addEventListener("click", () => openEventDetailsDialog(ev));
    col.appendChild(el);
  });
}

// view switch
function switchToWeek(){
  currentView="week";
  tabWeek.classList.add("active");
  tabMonth.classList.remove("active");
  document.getElementById("calendarView").classList.remove("hidden");
  document.getElementById("monthView").classList.add("hidden");
  updateMonthLabel(); updateHeaderDates(current); renderEvents();
}
function switchToMonth(){
  currentView="month";
  tabMonth.classList.add("active");
  tabWeek.classList.remove("active");
  document.getElementById("calendarView").classList.add("hidden");
  document.getElementById("monthView").classList.remove("hidden");
  updateMonthLabel(); buildMonthGrid(current);
}
tabWeek.addEventListener("click", switchToWeek);
tabMonth.addEventListener("click", switchToMonth);
prevBtn.addEventListener("click", () => {
  if (currentView==="week"){ current.setDate(current.getDate()-7); switchToWeek(); }
  else { current.setMonth(current.getMonth()-1); switchToMonth(); }
});
nextBtn.addEventListener("click", () => {
  if (currentView==="week"){ current.setDate(current.getDate()+7); switchToWeek(); }
  else { current.setMonth(current.getMonth()+1); switchToMonth(); }
});
todayBtn.addEventListener("click", () => { current = new Date(); currentView==="week"?switchToWeek():switchToMonth(); });

// month grid
function buildMonthGrid(base){
  monthGrid.innerHTML = "";
  const year = base.getFullYear(), month = base.getMonth();
  const first = new Date(year, month, 1);
  const start = startOfWeek(first);
  const todayStr = new Date().toDateString();
  for (let i=0;i<42;i++){
    const d = new Date(start); d.setDate(start.getDate()+i);
    const cell = document.createElement("div");
    cell.className = "month-cell";
    if (d.getMonth() !== month) cell.classList.add("out");
    if (d.toDateString() === todayStr) cell.classList.add("today");
    cell.innerHTML = `<div class="mday">${d.getDate()}</div>`;
    cell.dataset.iso = d.toISOString().slice(0,10);
    cell.addEventListener("click", () => { current = new Date(d); switchToWeek(); });
    monthGrid.appendChild(cell);
  }
}

// popup mini & side mini
function renderMiniCalendar(container, titleEl, base) {
  container.innerHTML = "";
  titleEl.textContent = `${monthNames[base.getMonth()]} ${base.getFullYear()}`;
  "SMTWTFS".split("").forEach(c => {
    const h=document.createElement("div"); h.className="dow-s"; h.textContent=c; container.appendChild(h);
  });
  const first = new Date(base.getFullYear(), base.getMonth(), 1);
  const start = startOfWeek(first);
  const todayStr = new Date().toDateString();
  for (let i=0; i<42; i++){
    const d = new Date(start); d.setDate(start.getDate()+i);
    const el = document.createElement("div");
    el.className = "mini-day";
    if (d.getMonth() !== base.getMonth()) el.classList.add("out");
    if (d.toDateString() === todayStr) el.classList.add("today");
    el.textContent = d.getDate();
    el.addEventListener("click", () => {
      current = new Date(d); switchToWeek(); monthPopup.classList.add("hidden");
    });
    container.appendChild(el);
  }
}
let miniCursor = new Date(current), popCursor = new Date(current);
function paintSideMini(){ renderMiniCalendar(miniCalendar, miniTitle, miniCursor); }
function paintPopMini(){ renderMiniCalendar(popCalendar, popTitle, popCursor); }
miniPrev.addEventListener("click", () => { miniCursor.setMonth(miniCursor.getMonth()-1); paintSideMini(); });
miniNext.addEventListener("click", () => { miniCursor.setMonth(miniCursor.getMonth()+1); paintSideMini(); });
popPrev.addEventListener("click", () => { popCursor.setMonth(popCursor.getMonth()-1); paintPopMini(); });
popNext.addEventListener("click", () => { popCursor.setMonth(popCursor.getMonth()+1); paintPopMini(); });
monthLabelBtn.addEventListener("click", () => { popCursor=new Date(current); paintPopMini(); monthPopup.classList.remove("hidden"); });
monthPopup.addEventListener("click", (e) => { if (e.target===monthPopup) monthPopup.classList.add("hidden"); });
paintSideMini();

// ====== Create Event (adds creator to participants) ======
const eventNameInput = document.getElementById("eventNameInput");
const eventVenueInput = document.getElementById("eventVenueInput");
const eventStartDate = document.getElementById("eventStartDateInput");
const eventStopDate = document.getElementById("eventEndDateInput");
const createEventBtn = document.getElementById("createEventBtn");
const cancelCreateBtn = document.getElementById("cancelCreateBtn");
const eventDialog = document.getElementById("createEventDialog");
document.getElementById("create-event").addEventListener("click", () => eventDialog.classList.remove("hidden"));
cancelCreateBtn.addEventListener("click", () => eventDialog.classList.add("hidden"));
document.addEventListener("keydown", (e)=>{ if(e.key==="Escape"){ eventDialog.classList.add("hidden"); editEventDialog.classList.add("hidden"); eventDetailsDialog.classList.add("hidden"); }});

createEventBtn.addEventListener("click", async () => {
  const name = eventNameInput.value.trim();
  const venue = eventVenueInput.value.trim();
  const startDate = new Date(eventStartDate.value).getTime();
  const endDate = new Date(eventStopDate.value).getTime();
  if (!name || !venue || !startDate || !endDate) { alert("Please fill in all fields."); return; }

  try {
    const resp = await fetch(`${BackendUrl}/events/create`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${authInfo.token}`,
      },
      body: JSON.stringify({
        event: {
          name,
          date: startDate,
          end_date: endDate,
          participants: [authInfo.username], // include creator so they get notifications
          venue
        }
      })
    });
    if (!resp.ok) { alert("Failed to create event"); return; }
    eventDialog.classList.add("hidden");
    eventNameInput.value = eventVenueInput.value = ""; eventStartDate.value = eventEndDate.value = "";
    await getEvents();
    alert("✅ Event created!");
  } catch (e) { console.error(e); }
});

// ====== Event Details (view) & Edit (admin) ======
const eventDetailsDialog = document.getElementById("eventDetailsDialog");
const detailsEventName = document.getElementById("detailsEventName");
const detailsEventVenue = document.getElementById("detailsEventVenue");
const detailsEventStart = document.getElementById("detailsEventStart");
const detailsEventEnd = document.getElementById("detailsEventEnd");
const detailsEventParticipants = document.getElementById("detailsEventParticipants");
const editEventBtn = document.getElementById("editEventBtn");
const closeDetailsBtn = document.getElementById("closeDetailsBtn");

const editEventDialog = document.getElementById("editEventDialog");
const editEventNameInput = document.getElementById("editEventNameInput");
const editEventVenueInput = document.getElementById("editEventVenueInput");
const editEventStartDateInput = document.getElementById("editEventStartDateInput");
const editEventEndDateInput = document.getElementById("editEventEndDateInput");
const participantUsernameInput = document.getElementById("participantUsernameInput");
const addParticipantBtn = document.getElementById("addParticipantBtn");
const removeParticipantBtn = document.getElementById("removeParticipantBtn");
const participantsPills = document.getElementById("participantsPills");
const updateEventBtn = document.getElementById("updateEventBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");

let selectedEvent = null;

function openEventDetailsDialog(ev){
  selectedEvent = structuredClone(ev);
  detailsEventName.textContent = ev.title;
  detailsEventVenue.textContent = ev.venue || "—";
  detailsEventStart.textContent = new Date(ev.startEpoch).toLocaleString();
  detailsEventEnd.textContent = new Date(ev.endEpoch).toLocaleString();
  const parts = ev.participants?.length ? ev.participants.join(", ") : "None";
  detailsEventParticipants.textContent = parts;

  // Only admins can edit
  editEventBtn.style.display = authInfo.role === 0 ? "inline-block" : "none";

  eventDetailsDialog.classList.remove("hidden");
}
closeDetailsBtn.addEventListener("click", () => eventDetailsDialog.classList.add("hidden"));

editEventBtn.addEventListener("click", () => {
  if (authInfo.role !== 0) return; // guard
  eventDetailsDialog.classList.add("hidden");

  editEventNameInput.value = selectedEvent.title;
  editEventVenueInput.value = selectedEvent.venue || "";
  editEventStartDateInput.value = new Date(selectedEvent.startEpoch).toISOString().slice(0,16);
  editEventEndDateInput.value = new Date(selectedEvent.endEpoch).toISOString().slice(0,16);
  paintParticipantPills(selectedEvent.participants);

  editEventDialog.classList.remove("hidden");
});
cancelEditBtn.addEventListener("click", () => editEventDialog.classList.add("hidden"));

function paintParticipantPills(list){
  participantsPills.innerHTML = "";
  (list || []).forEach(u => {
    const pill = document.createElement("span");
    pill.className = "pill";
    pill.textContent = u;
    participantsPills.appendChild(pill);
  });
}

// --- update name (only editable field supported by backend) ---
updateEventBtn.addEventListener("click", async () => {
  if (!selectedEvent) return;
  if (authInfo.role !== 0) { alert("Only administrators can edit events."); return; }

  const newName = editEventNameInput.value.trim();
  if (!newName) { alert("Event name cannot be empty."); return; }
  if (newName === selectedEvent.title) { editEventDialog.classList.add("hidden"); return; }

  try {
    const resp = await fetch(`${BackendUrl}/events/change_name`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${authInfo.token}`,
      },
      body: JSON.stringify({ target: selectedEvent.name, updated: newName })
    });
    if (!resp.ok) { alert("Failed to update event name"); return; }
    editEventDialog.classList.add("hidden");
    await getEvents();
    alert("✅ Event updated!");
  } catch (e) { console.error(e); }
});

// --- participants: add/remove by username ---
async function mutateParticipant(kind){
  if (!selectedEvent) return;
  if (authInfo.role !== 0) { alert("Only administrators can modify participants."); return; }
  const uname = participantUsernameInput.value.trim();
  if (!uname) { alert("Enter a username."); return; }
  const url = kind === "add" ? `${BackendUrl}/events/add_participants` : `${BackendUrl}/events/remove_participants`;
  const payload = kind === "add"
    ? { target: selectedEvent.name, updated: uname }
    : { target: selectedEvent.name, remove: uname };

  const resp = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${authInfo.token}`,
    },
    body: JSON.stringify(payload)
  });
  if (!resp.ok) {
    if (kind === "remove") alert("Could not remove (user not in event?)");
    else alert("Could not add participant.");
    return;
  }
  // optimistic UI refresh
  if (kind === "add" && !selectedEvent.participants.includes(uname)) {
    selectedEvent.participants.push(uname);
  }
  if (kind === "remove") {
    selectedEvent.participants = selectedEvent.participants.filter(u => u !== uname);
  }
  paintParticipantPills(selectedEvent.participants);
  participantUsernameInput.value = "";
  await getEvents();
}
addParticipantBtn.addEventListener("click", () => mutateParticipant("add"));
removeParticipantBtn.addEventListener("click", () => mutateParticipant("remove"));

// clicking event opens details
function addEventClickHandlers(){ /* already added in renderEvents via addEventListener */ }
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && document.activeElement === participantUsernameInput) {
    addParticipantBtn.click();
  }
});

// ====== Sidebar/collapsed toggles ======
hamburger.addEventListener("click", () => {
  shell.classList.toggle("collapsed");
  eventDialog.classList.add("hidden");
  collapsedCreate.style.display = "none";
});
collapsedPlus.addEventListener("click", (e) => {
  e.stopPropagation();
  collapsedCreate.style.display =
    collapsedCreate.style.display === "block" ? "none" : "block";
  eventDialog.classList.remove("hidden");
});
document.addEventListener("click", (e) => {
  if (!collapsedCreate.contains(e.target) && e.target !== collapsedPlus) {
    collapsedCreate.style.display = "none";
  }
  // hide any open dialog when clicking outside
  if (e.target.classList?.contains("modal")) e.target.classList.add("hidden");
});

// ====== Tasks/Upcoming (unchanged) ======
let tasks = [
  { text: "Prepare website for Dexterity", due: "in [2] days", done: true },
  { text: "Go to Silico Battles 21.1", due: "in [5] days", done: false },
  { text: "Collect the rolling trophy", due: "in [5] days", done: false },
];
function paintTasks() {
  tasksList.innerHTML = tasks.map((t,i)=>`
    <label class="task">
      <input type="checkbox" ${t.done?"checked":""} data-index="${i}">
      <span class="custom"></span>
      <span class="text">${t.text}</span>
      <span class="due">${t.due}</span>
    </label>
  `).join("");
}
paintTasks();
tasksList.addEventListener("change", (e)=>{
  if (e.target.tagName === "INPUT") {
    const idx = e.target.dataset.index;
    tasks[idx].done = e.target.checked;
    paintTasks();
  }
});
addTaskBtn.addEventListener("click", ()=>{
  const text = prompt("Enter new task:");
  if (text) { tasks.push({ text, due: "no due date", done: false }); paintTasks(); }
});
function paintUpcoming(){
  upcomingList.innerHTML = events.map(e=>`
    <li class="event-item">
      <strong>${e.title}</strong>
      <span>${new Date(e.startEpoch).toLocaleString()} – ${new Date(e.endEpoch).toLocaleString()}</span>
    </li>
  `).join("");
}

// ====== Notifications (< 4 hours) ======
const notifTray = document.getElementById("notifTray");
const notifiedKey = "notifiedEvents"; // store names + startEpoch to avoid repeats
function getNotifiedSet(){
  try { return new Set(JSON.parse(localStorage.getItem(notifiedKey) || "[]")); }
  catch { return new Set(); }
}
function saveNotifiedSet(set){
  localStorage.setItem(notifiedKey, JSON.stringify(Array.from(set)));
}

async function ensureNotificationPermission(){
  if (!("Notification" in window)) return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission !== "denied") {
    try { const p = await Notification.requestPermission(); return p==="granted"; }
    catch { return false; }
  }
  return false;
}
function pushInApp(text) {
  const card = document.createElement("div");
  card.className = "notif";
  card.textContent = text;
  notifTray.appendChild(card);
  setTimeout(() => card.remove(), 8000);
}

function checkImminentEvents(){
  const now = Date.now();
  const fourHours = 4*60*60*1000;
  const noted = getNotifiedSet();
  const mine = events.filter(e => e.participants?.includes(authInfo.username));
  mine.forEach(e => {
    if (e.startEpoch - now <= fourHours && e.startEpoch - now > 0) {
      const key = `${e.name}|${e.startEpoch}`;
      if (!noted.has(key)) {
        noted.add(key);
        saveNotifiedSet(noted);
        const msg = `“${e.title}” starts at ${new Date(e.startEpoch).toLocaleTimeString()} (in < 4 hours).`;
        pushInApp(msg);
        if ("Notification" in window && Notification.permission === "granted") {
          new Notification("Event reminder", { body: msg });
        }
      }
    }
  });
}

// run every minute
setInterval(checkImminentEvents, 60*1000);

// ====== init ======
(async function init(){
  await updateAuthInfo();
  await getEvents();
  // ask once for browser notifications
  ensureNotificationPermission();
  // initial paints
  updateMonthLabel(); updateHeaderDates(current);
  switchToWeek();
})();
